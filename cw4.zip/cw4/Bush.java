
/**
 * Write a description of class Cactus here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class Bush extends Obstacle {

    public Bush() {
        super(); 
        buildBush();
    }

    private void buildBush() {
        // Допустим, куст состоит из трёх кругов, 
        // расположенных «в кучку» (примерно как у Google Dino).
        Circle leaf1 = new Circle(0,  0,  20);
        Circle leaf2 = new Circle(20, 0,  20);
        Circle leaf3 = new Circle(10, -20, 20);

        leaf1.setFill(Color.GREEN);
        leaf2.setFill(Color.GREEN);
        leaf3.setFill(Color.GREEN);

        obstacleGroup.getChildren().addAll(leaf1, leaf2, leaf3);

        // Начальные координаты
        this.x = 600; // например, за правым краем сцены
        this.y = 250; // высота «земли» в вашей игре
        obstacleGroup.setLayoutX(x);
        obstacleGroup.setLayoutY(y);
    }
}
