
/**
 * Write a description of class ObstacleFactory here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ObstacleFactory
{
    private static ObstacleFactory instance;

    private ObstacleFactory() {}

    public static ObstacleFactory getInstance() {
        if (instance == null) {
            instance = new ObstacleFactory();
        }
        return instance;
    }

    // Можно передавать строку "Bush", "Bushes" или "Bird"
    public Obstacle generateObstacle(String obstacleType) {
        obstacleType = obstacleType.toLowerCase();
        switch (obstacleType) {
            case "bush":
                return new Bush();
            case "bushes":
                return new Bushes();
            case "bird":
                return new Bird();
            default:
                return null;
        }
    }
}

