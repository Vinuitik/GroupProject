
/**
 * Write a description of class Bird here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Polygon;
import javafx.util.Duration;

public class Bird extends Obstacle {

    private Timeline flapAnimation;

    public Bird() {
        super();
        buildBird();
        setupFlapAnimation();
    }

    private void buildBird() {
        Circle body = new Circle(0, 0, 10);
        body.setFill(Color.DODGERBLUE);

        Polygon wing = new Polygon(
            -5.0, 0.0,
            -10.0, -5.0,
            -2.0, -3.0
        );
        wing.setFill(Color.WHITE);

        obstacleGroup.getChildren().addAll(body, wing);

        this.x = 600;
        this.y = 150;
        obstacleGroup.setLayoutX(x);
        obstacleGroup.setLayoutY(y);
    }

    private void setupFlapAnimation() {
        // Пример простого «взмаха» крыла
        Polygon wing = (Polygon) obstacleGroup.getChildren().get(1);

        flapAnimation = new Timeline(
            new KeyFrame(Duration.ZERO, e -> wing.setRotate(0)),
            new KeyFrame(Duration.seconds(0.1), e -> wing.setRotate(20)),
            new KeyFrame(Duration.seconds(0.2), e -> wing.setRotate(0))
        );
        flapAnimation.setCycleCount(Timeline.INDEFINITE);
        flapAnimation.play();
    }
}
