import javafx.scene.Group;

public class Obstacle {
    // Координаты препятствия
    protected double x;
    protected double y;

    // Группа фигур (JavaFX) для отрисовки куста/кустов/птички
    protected Group obstacleGroup;

    public Obstacle() {
        obstacleGroup = new Group();
    }

    public Group getNode() {
        return obstacleGroup;
    }

    // Пример метода для перемещения препятствия влево
    public void update(double delta) {
        x -= delta; 
        obstacleGroup.setLayoutX(x);
    }

    // Геттеры/сеттеры при необходимости
    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
        obstacleGroup.setLayoutX(x);
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
        obstacleGroup.setLayoutY(y);
    }
}
