
/**
 * Write a description of class Cactuses here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class Bushes extends Obstacle {

    public Bushes() {
        super();
        buildBushes();
    }

    private void buildBushes() {
        // Допустим, хотим 2 или 3 куста подряд. 
        // Можно сделать рандом или фиксированное количество.

        int numberOfBushes = (Math.random() < 0.5) ? 2 : 3;

        double offsetX = 0;
        for (int i = 0; i < numberOfBushes; i++) {
            // Каждый куст пусть будет состоять из трёх кругов
            Circle leaf1 = new Circle(offsetX + 0,  0,  20);
            Circle leaf2 = new Circle(offsetX + 20, 0,  20);
            Circle leaf3 = new Circle(offsetX + 10, -20, 20);

            leaf1.setFill(Color.GREEN);
            leaf2.setFill(Color.GREEN);
            leaf3.setFill(Color.GREEN);

            obstacleGroup.getChildren().addAll(leaf1, leaf2, leaf3);

            // Смещаем начало следующего куста по оси X
            offsetX += 60; 
        }

        this.x = 600; 
        this.y = 250;
        obstacleGroup.setLayoutX(x);
        obstacleGroup.setLayoutY(y);
    }
}
