import javafx.util.Pair;
import java.awt.Point;
/**
 * Write a description of class Cactuses here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Cactuses extends Obstacle

{


    @Override
    public void start(){}
    @Override
    public void spawn(){}
    @Override
    public void move(){}
    @Override
    public Pair<Point,Point> getBoundingBox(){
        return null;
    }
}
