import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Menu class for the Dinosaur Game
 * Creates a menu bar with options for Start, File, and Help
 * 
 * @author Dima, Daria, David
 * @version 1.0
 */
public class Menu
{
    private JFrame frame;
    private JMenuBar menuBar;
    private Scene gameScene;
    
    /**
     * Constructor for objects of class Menu
     */
    public Menu(JFrame frame, Scene gameScene)
    {
        this.frame = frame;
        this.gameScene = gameScene;
        createMenu();
    }
    
    /**
     * Constructor for objects of class Menu with default frame
     */
    public Menu()
    {
        this.frame = new JFrame("Dinosaur Game");
        this.frame.setSize(800, 400);
        this.frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.frame.setVisible(true);
        createMenu();
    }
    
    /**
     * Creates the menu bar with all options
     */
    private void createMenu()
    {
        // Create menu bar
        menuBar = new JMenuBar();
        
        // Create Start menu
        JMenu startMenu = new JMenu("Start");
        JMenuItem startGame = new JMenuItem("Start Game");
        startGame.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                startGameAction();
            }
        });
        startMenu.add(startGame);
        
        // Create File menu
        JMenu fileMenu = new JMenu("File");
        JMenuItem quitItem = new JMenuItem("Quit");
        quitItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                quitGame();
            }
        });
        fileMenu.add(quitItem);
        
        // Create Help menu
        JMenu helpMenu = new JMenu("Help");
        JMenuItem aboutItem = new JMenuItem("About");
        aboutItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                showAboutDialog();
            }
        });
        helpMenu.add(aboutItem);
        
        // Add menus to menu bar
        menuBar.add(startMenu);
        menuBar.add(fileMenu);
        menuBar.add(helpMenu);
        
        // Set menu bar to frame
        frame.setJMenuBar(menuBar);
    }
    
    /**
     * Starts the game when Start option is selected
     */
    private void startGameAction()
    {
        // Here you would initialize the game
        if (gameScene != null) {
            // Call any initialization methods on gameScene
            JOptionPane.showMessageDialog(frame, "Game started!", "Start Game", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(frame, "Game scene not initialized!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Quits the game when Quit option is selected
     */
    private void quitGame()
    {
        int response = JOptionPane.showConfirmDialog(
            frame, 
            "Are you sure you want to quit?", 
            "Quit Game", 
            JOptionPane.YES_NO_OPTION
        );
        
        if (response == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }
    
    /**
     * Shows the About dialog with game title and authors
     */
    private void showAboutDialog()
    {
        JOptionPane.showMessageDialog(
            frame,
            "Dinosaur Game\n\nAuthors:\n- Dima\n- Daria\n- David",
            "About",
            JOptionPane.INFORMATION_MESSAGE
        );
    }
    
    /**
     * Returns the menu bar
     * 
     * @return JMenuBar the menu bar
     */
    public JMenuBar getMenuBar()
    {
        return menuBar;
    }
    
    /**
     * Sets the game scene
     * 
     * @param gameScene the Scene object to set
     */
    public void setGameScene(Scene gameScene)
    {
        this.gameScene = gameScene;
    }
    
    /**
     * For testing the menu independently
     */
    public static void main(String[] args)
    {
        new Menu();
    }
}