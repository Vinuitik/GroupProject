
/**
 * Write a description of class Player here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Charachter
{
    /**
     * Constructor for objects of class Player
     */
    public Charachter()
    {
        
    }
}
