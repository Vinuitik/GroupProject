import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JPanel;
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.awt.Color;

/**
 * Write a description of class BackgroundPanel here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
/**
     * Custom JPanel with background image
     */
    public class BackgroundPanel extends JPanel {
        private BufferedImage backgroundImage;
        
        public BackgroundPanel(Color BACKGROUND_COLOR) {
            try {
                // Load the background image
                backgroundImage = ImageIO.read(new File("background.jpg"));
            } catch (IOException e) {
                e.printStackTrace();
                // Fallback to default color if image can't be loaded
                setBackground(BACKGROUND_COLOR);
            }
        }
        
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (backgroundImage != null) {
                // Scale image to fit the panel
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
                g2d.dispose();
            }
        }
    }
