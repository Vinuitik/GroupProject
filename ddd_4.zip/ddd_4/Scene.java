import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Random;

/**
 * Scene class for the Dinosaur Game
 * Manages the game background, including ground, clouds, and game elements
 * 
 * @author Dima, Daria, David
 * @version 1.0
 */
public class Scene extends JPanel implements ActionListener
{
    // Game state
    private boolean isRunning = false;
    private boolean isGameOver = false;
    private int score = 0;
    private int highScore = 0;
    
    // Game speed and scroll control
    private int scrollSpeed = 5;
    private int groundY;
    
    // Ground elements
    private ArrayList<Rectangle> grounds = new ArrayList<>();
    private static final int GROUND_HEIGHT = 20;
    private static final int GROUND_WIDTH = 50;
    
    // Cloud elements
    private ArrayList<Rectangle> clouds = new ArrayList<>();
    private static final int CLOUD_HEIGHT = 30;
    private static final int MIN_CLOUD_WIDTH = 50;
    private static final int MAX_CLOUD_WIDTH = 80;
    
    // Game character
    private Dinosaur player;
    
    // Obstacles
    private ArrayList<Obstacle> obstacles = new ArrayList<>();
    private ObstacleFactory obstacleFactory;
    private int obstacleTimer = 0;
    private Random random = new Random();
    
    // Animation
    private Timer timer;
    private static final int DELAY = 20; // milliseconds
    
    /**
     * Constructor for objects of class Scene
     */
    public Scene()
    {
        // Initialize scene
        setBackground(Color.WHITE);
        setFocusable(true);
        
        // Initialize game objects
        obstacleFactory = ObstacleFactory.getInstance();
        player = new Dinosaur();
        
        // Set up keyboard controls
        setupKeyBindings();
        
        // Set up timer for animation
        timer = new Timer(DELAY, this);
    }
    
    /**
     * Sets up keyboard controls for the game
     */
    private void setupKeyBindings() {
        // Jump with space or up arrow
        this.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(
            KeyStroke.getKeyStroke(KeyEvent.VK_SPACE, 0), "jump");
        this.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(
            KeyStroke.getKeyStroke(KeyEvent.VK_UP, 0), "jump");
        
        this.getActionMap().put("jump", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Handle jump action
                if (isRunning && !isGameOver) {
                    // This would call the dinosaur's jump method
                    // player.jump();
                } else if (!isRunning) {
                    // Start game on first keypress
                    startGame();
                } else if (isGameOver) {
                    // Restart game if game over
                    resetGame();
                }
            }
        });
    }
    
    /**
     * Initializes the ground segments
     */
    private void initializeGround() {
        grounds.clear();
        groundY = getHeight() - GROUND_HEIGHT;
        
        // Create initial ground segments to fill the screen
        int numSegments = getWidth() / GROUND_WIDTH + 2;
        for (int i = 0; i < numSegments; i++) {
            grounds.add(new Rectangle(i * GROUND_WIDTH, groundY, GROUND_WIDTH, GROUND_HEIGHT));
        }
    }
    
    /**
     * Adds a new cloud to the scene
     */
    private void addCloud() {
        int cloudWidth = random.nextInt(MAX_CLOUD_WIDTH - MIN_CLOUD_WIDTH) + MIN_CLOUD_WIDTH;
        int cloudY = random.nextInt(groundY / 2); // Clouds in upper half of screen
        clouds.add(new Rectangle(getWidth(), cloudY, cloudWidth, CLOUD_HEIGHT));
    }
    
    /**
     * Adds a new obstacle to the scene
     */
    private void addObstacle() {
        String[] obstacleTypes = {"Bird", "Cactus", "Cactuses"};
        String type = obstacleTypes[random.nextInt(obstacleTypes.length)];
        
        Obstacle newObstacle = obstacleFactory.generateObstacle(type);
        newObstacle.spawn(); // Set up obstacle
        obstacles.add(newObstacle);
    }
    
    /**
     * Updates the scene elements for each frame
     */
    private void updateScene() {
        if (!isRunning || isGameOver) return;
        
        // Update score
        score++;
        
        // Update ground position
        updateGround();
        
        // Update clouds
        updateClouds();
        
        // Update obstacles
        updateObstacles();
        
        // Check for collisions
        checkCollisions();
        
        // Maybe add new obstacles
        obstacleTimer++;
        if (obstacleTimer > 100) { // Adjust timing based on testing
            if (random.nextInt(10) < 3) { // 30% chance to add obstacle
                addObstacle();
                obstacleTimer = 0;
            }
        }
        
        // Increase game speed over time
        if (score % 500 == 0) {
            scrollSpeed++;
        }
    }
    
    /**
     * Updates the ground segments
     */
    private void updateGround() {
        for (int i = 0; i < grounds.size(); i++) {
            Rectangle ground = grounds.get(i);
            ground.x -= scrollSpeed;
        }
        
        // Remove ground segments that are off-screen
        if (!grounds.isEmpty() && grounds.get(0).x + GROUND_WIDTH < 0) {
            grounds.remove(0);
            
            // Add new ground segment at the end
            Rectangle last = grounds.get(grounds.size() - 1);
            grounds.add(new Rectangle(last.x + GROUND_WIDTH, groundY, GROUND_WIDTH, GROUND_HEIGHT));
        }
    }
    
    /**
     * Updates the cloud positions and adds new ones
     */
    private void updateClouds() {
        // Move clouds
        for (int i = 0; i < clouds.size(); i++) {
            Rectangle cloud = clouds.get(i);
            cloud.x -= scrollSpeed / 2; // Clouds move slower than ground
        }
        
        // Remove clouds that are off-screen
        if (!clouds.isEmpty() && clouds.get(0).x + clouds.get(0).width < 0) {
            clouds.remove(0);
        }
        
        // Randomly add new clouds
        if (random.nextInt(100) < 1) { // 1% chance each frame
            addCloud();
        }
    }
    
    /**
     * Updates the obstacles
     */
    private void updateObstacles() {
        for (Obstacle obstacle : obstacles) {
            obstacle.move();
        }
        
        // Remove obstacles that are off-screen
        for (int i = obstacles.size() - 1; i >= 0; i--) {
            // This would need more implementation based on your Obstacle class
            // if (obstacles.get(i).isOffScreen()) {
            //     obstacles.remove(i);
            // }
        }
    }
    
    /**
     * Checks for collisions between player and obstacles
     */
    private void checkCollisions() {
        // This would need implementation specific to your collision detection
        // For example:
        // for (Obstacle obstacle : obstacles) {
        //     if (player.intersects(obstacle)) {
        //         gameOver();
        //     }
        // }
    }
    
    /**
     * Starts the game
     */
    public void startGame() {
        isRunning = true;
        isGameOver = false;
        score = 0;
        
        // Initialize game elements
        initializeGround();
        clouds.clear();
        obstacles.clear();
        
        // Start the timer
        timer.start();
    }
    
    /**
     * Ends the game
     */
    private void gameOver() {
        isGameOver = true;
        isRunning = false;
        
        // Update high score
        if (score > highScore) {
            highScore = score;
        }
    }
    
    /**
     * Resets the game after game over
     */
    private void resetGame() {
        startGame();
    }
    
    /**
     * Paint method to draw the scene
     */
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        
        Graphics2D g2d = (Graphics2D) g;
        
        // Draw sky (background)
        g2d.setColor(Color.WHITE);
        g2d.fillRect(0, 0, getWidth(), getHeight());
        
        // Draw clouds
        g2d.setColor(new Color(200, 200, 200));
        for (Rectangle cloud : clouds) {
            g2d.fillOval(cloud.x, cloud.y, cloud.width, cloud.height);
        }
        
        // Draw ground
        g2d.setColor(new Color(83, 83, 83));
        for (Rectangle ground : grounds) {
            g2d.fillRect(ground.x, ground.y, ground.width, ground.height);
        }
        
        // Draw player (dinosaur)
        // This would be implemented based on your Dinosaur class
        // player.draw(g2d);
        
        // Draw obstacles
        // This would be implemented based on your Obstacle classes
        // for (Obstacle obstacle : obstacles) {
        //     obstacle.draw(g2d);
        // }
        
        // Draw score
        g2d.setColor(Color.BLACK);
        g2d.setFont(new Font("Arial", Font.BOLD, 20));
        g2d.drawString("Score: " + score, 20, 30);
        g2d.drawString("High Score: " + highScore, 20, 60);
        
        // Draw game messages
        if (!isRunning && !isGameOver) {
            // Start message
            drawCenteredText(g2d, "Press SPACE to start", getHeight() / 2);
        } else if (isGameOver) {
            // Game over message
            drawCenteredText(g2d, "GAME OVER", getHeight() / 2);
            drawCenteredText(g2d, "Press SPACE to restart", getHeight() / 2 + 40);
        }
    }
    
    /**
     * Helper method to draw centered text
     */
    private void drawCenteredText(Graphics2D g2d, String text, int y) {
        FontMetrics metrics = g2d.getFontMetrics();
        int x = (getWidth() - metrics.stringWidth(text)) / 2;
        g2d.drawString(text, x, y);
    }
    
    /**
     * Timer action event handler
     */
    @Override
    public void actionPerformed(ActionEvent e) {
        updateScene();
        repaint();
    }
    
    /**
     * Returns whether the game is currently running
     */
    public boolean isRunning() {
        return isRunning;
    }
    
    /**
     * Returns whether the game is over
     */
    public boolean isGameOver() {
        return isGameOver;
    }
    
    /**
     * Returns the current score
     */
    public int getScore() {
        return score;
    }
    
    /**
     * Pauses the game
     */
    public void pauseGame() {
        if (isRunning) {
            timer.stop();
            isRunning = false;
        }
    }
    
    /**
     * Resumes the game
     */
    public void resumeGame() {
        if (!isGameOver && !isRunning) {
            timer.start();
            isRunning = true;
        }
    }
}